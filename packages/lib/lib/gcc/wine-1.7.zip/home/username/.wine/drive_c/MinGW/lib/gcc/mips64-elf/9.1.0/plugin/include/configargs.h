/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-source/configure --build=x86_64-linux-gnu --host=x86_64-w64-mingw32 --prefix=/home/tyler/projects/n64chain/wintools --target=mips64-elf --with-arch=vr4300 --enable-languages=c --without-headers --with-newlib --with-gnu-as=/home/tyler/projects/n64chain/wintools/bin/mips64-elf-as.exe --with-gnu-ld=/home/tyler/projects/n64chain/wintools/bin/mips64-elf-ld.exe --enable-checking=release --enable-shared --enable-shared-libgcc --disable-decimal-float --disable-gold --disable-libatomic --disable-libgomp --disable-libitm --disable-libquadmath --disable-libquadmath-support --disable-libsanitizer --disable-libssp --disable-libunwind-exceptions --disable-libvtv --disable-multilib --disable-nls --disable-rpath --disable-static --disable-symvers --disable-threads --disable-win32-registry --enable-lto --enable-plugin --without-included-gettext";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "arch", "vr4300" } };
